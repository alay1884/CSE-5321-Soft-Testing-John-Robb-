package Homework5;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class Problem4ClassCORRECTEDTest {

	private Problem4ClassCORRECTED prb4;
	
	@Before
	public void setUp() throws Exception {
		prb4 = new Problem4ClassCORRECTED();
	}

	@FileParameters("//DISKSTATION/Family_Folder/John/UTA/2020/Spring/CSE 5321/Homework/HW 5/Solution/Problem 4 test case table.csv")
	@Test
	public void test(int testCaseNumber, Problem4ClassCORRECTED.state currentState, boolean C, boolean H, boolean N, boolean S, boolean X, String expD, boolean expG,Problem4ClassCORRECTED.state expNextState ) {
		prb4.setG(!expG);
		prb4.gasPump(currentState,C,H,N,S,X);
		assertEquals(expD,prb4.getD());
		assertEquals(expG,prb4.isG());
		assertEquals(expNextState,prb4.getNextState());
	}

}
